$(document).ready(function () {
    $('.small').hover(
				
        function () {
           $(this).animate({height:"35px"});
        }, 
         
        function () {
           $(this).animate({height:"20px"});
        }
     );
         
  });

  let gitHubRequest = new XMLHttpRequest();
  gitHubRequest.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      let gitObject = JSON.parse(this.responseText);
      document.getElementById("gitName").innerHTML = gitObject.name;
    }
  };
  gitHubRequest.open("GET", "https://api.github.com/users/xkj16", true);
  gitHubRequest.send();